import React, { useState } from "react";
import { motion } from "framer-motion";
import "../css/styles.css";

const cardsData = [
  {
    title: "Historia",
    icon: "🏛️",
    back: "Explorá el pasado de Jardín América y sumegte en una historia rica y vibrante que se remonta a principios del siglo XX.",
  },
  {
    title: "Arte y Cultura",
    icon: "🎨",
    back: "Descubrí la riqueza cultural y artística donde las tradiciones inmigrantes se fusionan con danzas, música y artesanías que reflejan la identidad de Misiones.",
  },
  {
    title: "Naturaleza",
    icon: "🌿",
    back: "Conocé la biodiversidad local con su tierra colorada, selva subtropical, arroyos cristalinos y fauna única que define el corazón verde de Misiones.",
  },
  {
    title: "Comunidad",
    icon: "🤝",
    back: "Conectate con las tradiciones locales donde la unión de sus habitantes brilla en festividades, trabajos cooperativos y el legado de sus raíces inmigrantes.",
  },
];

const cardVariant = {
  hidden: { opacity: 0, y: 40 },
  visible: (i) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.12 },
  }),
};

export default function Cards() {
  const [flipped, setFlipped] = useState(cardsData.map(() => false));

  const handleFlip = (index) => {
    setFlipped((prev) => prev.map((v, i) => (i === index ? !v : v)));
  };

  return (
    <div className="cards-grid">
      {cardsData.map((card, i) => (
        <motion.div
          key={i}
          className={`flip-card${flipped[i] ? " flipped" : ""}`}
          custom={i}
          variants={cardVariant}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: false, amount: 0.2 }}
          whileHover={flipped[i] ? {} : { y: -6 }}
          onClick={() => handleFlip(i)}
        >
          <div className="flip-inner">
            {/* Front */}
            <div className="flip-front">
              <div className="card-icon-wrap">{card.icon}</div>
              <h3>{card.title}</h3>
              <p className="flip-hint">Tocá para ver más →</p>
            </div>
            {/* Back */}
            <div className="flip-back">
              <h3>{card.title}</h3>
              <p>{card.back}</p>
              <p className="flip-hint-back">← Tocá para volver</p>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
