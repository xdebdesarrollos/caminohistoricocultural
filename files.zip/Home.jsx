import { motion } from "framer-motion";
import "../css/styles.css";
import Pie from "../components/Pie.jsx";
import Cards from "../components/Cards.jsx";

const fadeUp = {
  hidden: { opacity: 0, y: 48 },
  visible: { opacity: 1, y: 0 },
  exit:    { opacity: 0, y: -30 },
};

const stagger = {
  visible: { transition: { staggerChildren: 0.15 } },
};

export default function Home() {
  const images = [
    "Saltos1.jpg",
    "municipalidad.jpg",
    "Jardin-america.jpg",
    "fuenteagua.jpg",
    "plazaiglesia.jpg",
    "cartelnew.jpg",
  ];

  const howSteps = [
    {
      num: "1",
      title: "Abrí la cámara de tu celular",
      desc: "O usá una app lectora de QR. No hace falta instalar nada adicional.",
    },
    {
      num: "2",
      title: "Apuntá al código QR del panel",
      desc: "Cada panel informativo tiene su propio código en un punto estratégico de la ciudad.",
    },
    {
      num: "3",
      title: "Tocá el enlace que aparece",
      desc: "Se abrirá el sitio web con la información del lugar.",
    },
    {
      num: "4",
      title: "¡Listo! Explorá contenido histórico",
      desc: "Fotos, videos, mapas y el camino hacia el siguiente punto de interés.",
    },
  ];

  return (
    <>
      {/* ── HERO ── */}
      <header className="hero">
        <video className="hero-video" autoPlay loop muted playsInline>
          <source src="video/VideoLanding.mp4" type="video/mp4" />
        </video>
        <div className="hero-gradient" />
        <motion.div
          className="hero-content"
          initial="hidden"
          animate="visible"
          variants={stagger}
        >
          <motion.span className="hero-eyebrow" variants={fadeUp}>
            Jardín América · Misiones · Argentina
          </motion.span>
          <motion.h1 className="hero-title" variants={fadeUp}>
            Camino<br />
            <em>Histórico</em>
            <br />Cultural
          </motion.h1>
          <motion.p className="hero-sub" variants={fadeUp}>
            Descubrí la historia y cultura de Jardín América, Misiones
          </motion.p>
          <motion.a className="hero-cta" href="#about" variants={fadeUp}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 8 12 16" />
              <polyline points="8 12 12 16 16 12" />
            </svg>
            Explorar el camino
          </motion.a>
        </motion.div>
        <div className="hero-scroll">scroll</div>
      </header>

      {/* ── ABOUT ── */}
      <section className="about-section" id="about">
        <div className="container">
          <div className="about-grid">
            {[
              {
                label: "El proyecto",
                title: <>¿Qué es el Camino <span>Histórico/Cultural?</span></>,
                text: "Camino Cultural es un proyecto que busca enriquecer la experiencia turística y cultural de la ciudad de Jardín América. La iniciativa consiste en la instalación de paneles informativos con códigos QR en diferentes puntos estratégicos de la ciudad. Al escanear estos códigos, los visitantes acceden a información histórica, cultural y curiosidades sobre cada lugar. Además, el sistema sugiere otros destinos dentro del recorrido, facilitando la navegación mediante Google Maps o GPS.",
              },
              {
                label: "La motivación",
                title: <>¿Por qué <span>este proyecto?</span></>,
                text: "Para preservar la identidad cultural, fomentar el turismo y proporcionar una experiencia enriquecedora a residentes y visitantes de Jardín América, localidad ubicada en la Provincia de Misiones.",
                stats: true,
              },
            ].map((sec, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: false, amount: 0.2 }}
                transition={{ duration: 0.8, delay: i * 0.2 }}
              >
                <p className="section-label">{sec.label}</p>
                <h2 className="section-title">{sec.title}</h2>
                <div className="divider" />
                <p className="section-body">{sec.text}</p>
                {sec.stats && (
                  <div className="about-stat-grid">
                    {[
                      { num: "QR",   label: "Paneles informativos en la ciudad" },
                      { num: "📍",   label: "Puntos estratégicos del recorrido" },
                      { num: "🌿",   label: "Riqueza natural y cultural" },
                      { num: "100%", label: "Gratuito y accesible" },
                    ].map((s, j) => (
                      <motion.div
                        key={j}
                        className="stat-card"
                        variants={fadeUp}
                        initial="hidden"
                        whileInView="visible"
                        viewport={{ once: false }}
                        transition={{ duration: 0.6, delay: j * 0.1 }}
                        whileHover={{ y: -4, boxShadow: "0 12px 32px rgba(0,0,0,0.1)" }}
                      >
                        <div className="stat-num">{s.num}</div>
                        <div className="stat-label">{s.label}</div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CARDS ── */}
      <motion.section
        id="objectives"
        className="cards-section"
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: false, amount: 0.1 }}
        transition={{ duration: 0.8 }}
      >
        <div className="container">
          <p className="section-label light">Conocé Jardín América</p>
          <h2 className="section-title light">
            Cuatro pilares de <em>identidad</em>
          </h2>
          <p className="section-body dim">Hacé clic en cada tarjeta para descubrir más.</p>
          <Cards />
        </div>
      </motion.section>

      {/* ── GALLERY ── */}
      <motion.section
        id="gallery"
        className="gallery-section"
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: false, amount: 0.1 }}
        transition={{ duration: 0.8 }}
      >
        <div className="container">
          <p className="section-label">Galería</p>
          <h2 className="section-title">
            Descubrí la historia viva <span>en cada rincón</span>
          </h2>
          <div className="gallery-grid">
            {images.map((img, index) => (
              <motion.div
                key={index}
                className={`gallery-item${index === 0 ? " gallery-item--featured" : ""}`}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: false }}
                transition={{ duration: 0.7, delay: index * 0.08 }}
                whileHover={{ scale: 1.02 }}
              >
                <img
                  src={`images/JardinAmerica/${img}`}
                  alt={`Imagen ${index + 1}`}
                />
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>

      {/* ── MAP ── */}
      <motion.section
        id="mapa"
        className="map-section"
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: false, amount: 0.1 }}
        transition={{ duration: 0.8 }}
      >
        <div className="container">
          <div className="map-intro">
            <div>
              <p className="section-label">Mapa interactivo</p>
              <h2 className="section-title">
                Ubicación de los <span>paneles informativos</span>
              </h2>
            </div>
            <div className="map-note">
              <span className="map-dot" />
              Los marcadores amarillos indican cada panel en la ciudad
            </div>
          </div>
          <div className="map-embed-wrap">
            <iframe
              src="https://www.google.com/maps/d/embed?mid=1GswgKngHeyHmrw20zUT9AzN5yIGupVs&ehbc=2E312F"
              width="100%"
              height="480"
              style={{ border: 0, display: "block" }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Mapa del Camino Cultural"
            />
          </div>
        </div>
      </motion.section>

      {/* ── HOW IT WORKS ── */}
      <motion.section
        id="function"
        className="how-section"
        variants={fadeUp}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: false, amount: 0.1 }}
        transition={{ duration: 0.8 }}
      >
        <div className="container">
          <p className="section-label light">¿Cómo funciona?</p>
          <h2 className="section-title light">
            Cuatro pasos para <em>explorar</em>
          </h2>
          <div className="how-grid">
            <div className="how-steps">
              {howSteps.map((step, i) => (
                <motion.div
                  key={i}
                  className="how-step"
                  variants={fadeUp}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: false }}
                  transition={{ duration: 0.6, delay: i * 0.12 }}
                >
                  <div className="step-num">{step.num}</div>
                  <div className="step-text">
                    <h4>{step.title}</h4>
                    <p>{step.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
            <motion.div
              className="how-image-wrap"
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: false }}
              transition={{ duration: 0.9, delay: 0.3 }}
            >
              <img src="images/escaneo.png" alt="Persona escaneando el panel informativo" />
            </motion.div>
          </div>
        </div>
      </motion.section>

      <Pie />
    </>
  );
}
